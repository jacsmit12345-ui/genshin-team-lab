import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.genshinteamlab.app",
  appName: "Genshin Team Lab",
  webDir: "dist",
  android: { backgroundColor: "#101217" },
};

export default config;
