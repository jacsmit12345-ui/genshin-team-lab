const CACHE_NAME = "genshin-team-lab-shell-v1";
const APP_SHELL = ["/", "/manifest.webmanifest", "/team-lab-icon.svg"];
self.addEventListener("install", event => { event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL))); self.skipWaiting(); });
self.addEventListener("activate", event => { event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))))); self.clients.claim(); });
self.addEventListener("fetch", event => { const req=event.request, url=new URL(req.url); if(req.method!=="GET" || url.origin!==self.location.origin || url.pathname.startsWith("/api/")) return; event.respondWith(fetch(req).then(res=>{if(res.ok){const copy=res.clone(); caches.open(CACHE_NAME).then(cache=>cache.put(req,copy));} return res;}).catch(()=>caches.match(req).then(hit=>hit||caches.match("/")))); });
