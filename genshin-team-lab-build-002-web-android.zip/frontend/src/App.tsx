import { useEffect, useMemo, useState } from "react";
import { Activity, AlertCircle, Check, ChevronDown, Database, FlaskConical, Search, ShieldCheck, Sparkles, Users, X } from "lucide-react";
import type { Character } from "./types";

const API_BASE = import.meta.env.VITE_API_BASE ?? "";

const elementClass = (element: string) => element.toLowerCase();

function App() {
  const [characters, setCharacters] = useState<Character[]>([]);
  const [team, setTeam] = useState<(string | null)[]>(() => {
    try {
      const saved = localStorage.getItem("gtl-team");
      return saved ? JSON.parse(saved) as (string | null)[] : [null, null, null, null];
    } catch { return [null, null, null, null]; }
  });
  const [query, setQuery] = useState("");
  const [elementFilter, setElementFilter] = useState("All");
  const [activeSlot, setActiveSlot] = useState(0);
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [error, setError] = useState("");

  useEffect(() => {
    fetch(`${API_BASE}/api/characters`)
      .then(async response => {
        if (!response.ok) throw new Error(`API returned ${response.status}`);
        return response.json() as Promise<Character[]>;
      })
      .then(data => { setCharacters(data); setStatus("ready"); })
      .catch(err => { setError(err instanceof Error ? err.message : "Could not connect to API"); setStatus("error"); });
  }, []);

  useEffect(() => {
    localStorage.setItem("gtl-team", JSON.stringify(team));
  }, [team]);

  const selected = useMemo(() => team.map(id => characters.find(c => c.id === id) ?? null), [team, characters]);
  const filtered = useMemo(() => characters.filter(c =>
    c.name.toLowerCase().includes(query.toLowerCase()) &&
    (elementFilter === "All" || c.element === elementFilter)
  ), [characters, query, elementFilter]);

  function addCharacter(character: Character) {
    setTeam(old => {
      const next = [...old];
      const existing = next.indexOf(character.id);
      if (existing >= 0) next[existing] = null;
      next[activeSlot] = character.id;
      return next;
    });
    setActiveSlot((activeSlot + 1) % 4);
  }

  function removeCharacter(slot: number) {
    setTeam(old => old.map((id, index) => index === slot ? null : id));
  }

  const uniqueElements = ["All", ...Array.from(new Set(characters.map(c => c.element))).sort()];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><FlaskConical size={21}/></div>
          <div><div className="brand-name">TEAM LAB</div><div className="brand-sub">GENSHIN THEORYCRAFT</div></div>
        </div>
        <div className="nav-label">WORKSPACE</div>
        <div className="nav-item active"><Users size={17}/> Team Builder <span className="nav-count">01</span></div>
        <div className="nav-item disabled"><Database size={17}/> Character Database</div>
        <div className="nav-item disabled"><Activity size={17}/> Damage Analysis</div>
        <div className="nav-item disabled"><Sparkles size={17}/> Build Optimiser</div>
        <div className="sidebar-bottom">
          <div className="connection"><span className={`dot ${status}`}></span><span>{status === "ready" ? "API CONNECTED" : status === "loading" ? "CONNECTING…" : "API OFFLINE"}</span></div>
          <div className="version">BUILD 001 · FOUNDATION</div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div><div className="eyebrow">WORKSPACE / TEAM BUILDER</div><h1>Team configuration</h1></div>
          <div className="topbar-right"><span className="version-pill">LOCAL DEVELOPMENT</span><div className="avatar">TL</div></div>
        </header>

        <section className="intro">
          <div><div className="section-kicker">COMPOSITION WORKSPACE</div><h2>Build a team. Understand the mechanics.</h2><p>Configure a four-character team. Simulation and synergy analysis will be added in upcoming milestones.</p></div>
          <div className="intro-icon"><FlaskConical size={28}/></div>
        </section>

        {status === "error" && <div className="error-banner"><AlertCircle size={17}/><span>Backend unavailable: {error}. Start the FastAPI server using the README instructions.</span></div>}

        <div className="content-grid">
          <section className="panel team-panel">
            <div className="panel-heading"><div><div className="section-kicker">ACTIVE COMPOSITION</div><h3>Your team</h3></div><span className="counter">{team.filter(Boolean).length} / 4 SELECTED</span></div>
            <div className="team-slots">
              {selected.map((character, index) => (
                <button className={`team-slot ${activeSlot === index ? "slot-active" : ""}`} key={index} onClick={() => setActiveSlot(index)}>
                  <div className="slot-top"><span>SLOT 0{index + 1}</span>{character && <span className="slot-element">{character.element.toUpperCase()}</span>}</div>
                  {character ? <>
                    <div className={`character-monogram ${elementClass(character.element)}`}>{character.name.slice(0,1)}</div>
                    <strong>{character.name}</strong>
                    <span className="slot-role">{index === 0 ? "TEAM MEMBER" : "TEAM MEMBER"}</span>
                    <span className="remove" onClick={(event) => { event.stopPropagation(); removeCharacter(index); }}><X size={14}/></span>
                  </> : <>
                    <div className="empty-slot"><span>+</span></div><strong>Empty slot</strong><span className="slot-role">SELECT A CHARACTER</span>
                  </>}
                </button>
              ))}
            </div>
            <div className="slot-hint"><span className="hint-dot"></span> Select a slot, then choose a character from the roster.</div>
            <div className="analysis-placeholder">
              <div className="placeholder-head"><ShieldCheck size={17}/><strong>Analysis modules</strong><span>COMING NEXT</span></div>
              <div className="placeholder-grid">
                <div><small>TEAM SYNERGY</small><b>Not calculated</b></div>
                <div><small>DAMAGE OUTPUT</small><b>Not calculated</b></div>
                <div><small>ENERGY STATUS</small><b>Not calculated</b></div>
                <div><small>BUFF COVERAGE</small><b>Not calculated</b></div>
              </div>
            </div>
          </section>

          <section className="panel roster-panel">
            <div className="panel-heading"><div><div className="section-kicker">GAME DATA</div><h3>Character roster</h3></div><span className="counter">{characters.length} RECORDS</span></div>
            <div className="search-box"><Search size={16}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search characters…"/></div>
            <div className="filters">
              <label>ELEMENT <span className="select-wrap"><select value={elementFilter} onChange={e => setElementFilter(e.target.value)}>{uniqueElements.map(el => <option key={el}>{el}</option>)}</select><ChevronDown size={13}/></span></label>
              <span className="data-note"><Check size={13}/> Starter identity data</span>
            </div>
            <div className="roster-list">
              {status === "loading" && <div className="empty-state">Loading character records…</div>}
              {status === "ready" && filtered.map(character => (
                <button className="roster-row" key={character.id} onClick={() => addCharacter(character)}>
                  <div className={`roster-icon ${elementClass(character.element)}`}>{character.name.slice(0,1)}</div>
                  <div className="roster-info"><strong>{character.name}</strong><span>{character.element} · {character.weapon_type} · {character.rarity}★</span></div>
                  <span className="add-button">+</span>
                </button>
              ))}
              {status === "ready" && filtered.length === 0 && <div className="empty-state">No characters match your search.</div>}
            </div>
            <div className="roster-footer">DATA STATUS: IDENTITY VERIFIED · MECHANICS NOT YET IMPORTED</div>
          </section>
        </div>

        <footer className="footer"><span>GENSHIN TEAM LAB <b>·</b> BUILD 001</span><span>MECHANICS-FIRST THEORYCRAFTING</span></footer>
      </main>
    </div>
  );
}

export default App;
