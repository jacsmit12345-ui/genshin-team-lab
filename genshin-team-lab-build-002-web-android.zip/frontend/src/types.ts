export type Character = {
  id: string;
  name: string;
  rarity: number;
  element: string;
  weapon_type: string;
  region?: string | null;
  data_status: string;
  data_version: string;
};
