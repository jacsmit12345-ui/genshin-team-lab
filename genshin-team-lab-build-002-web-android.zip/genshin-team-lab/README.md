# Genshin Team Lab — Build 002

A local-first, mechanics-first Genshin Impact team theorycrafting app with a shared React web interface and Android app target.

## Supported targets
- **Web:** responsive desktop, tablet and mobile browser interface.
- **Installable web app (PWA):** installable from a supported browser; the app shell is cached, but live character data still needs the backend.
- **Android:** packaged from the same frontend using Capacitor 8.

The web and Android versions share the same UI and frontend code. The FastAPI backend is a separate service and must be reachable by the deployed app.

## What currently works
- React + TypeScript frontend (Vite)
- FastAPI backend and SQLite database
- Starter character roster API
- Character selection and four-slot team workspace
- Team saved locally on the device/browser
- Responsive mobile layout
- PWA manifest and app-shell service worker
- Capacitor Android configuration and build scripts

This is not yet a damage calculator. The PWA cache does not cache API responses or make the full app usable offline.

## Requirements
- Python 3.10+
- Node.js 22+
- Android builds: Android Studio and Android SDK

## 1. Start the backend
From the project root:
```bash
cd backend
python -m venv .venv
```
Activate with `.venv\Scripts\Activate.ps1` on Windows PowerShell or `source .venv/bin/activate` on macOS/Linux. Then:
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0
```
Backend: http://127.0.0.1:8000 · API docs: http://127.0.0.1:8000/docs

## 2. Run the web app
In a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the Vite URL, usually http://localhost:5173. The dev server proxies `/api` to FastAPI.

For production, set `VITE_API_BASE` to your public HTTPS backend URL before building. Example: `VITE_API_BASE=https://your-api.example.com npm run build` (PowerShell: `$env:VITE_API_BASE="https://your-api.example.com"; npm run build`). Do not use `127.0.0.1` for a hosted site or Android app: on a phone it points to the phone itself.

## 3. Create and run the Android app
Install Android Studio and an Android SDK. From `frontend`:
```bash
npm install
npm run android:add
npm run android:sync
npm run android:open
```
Select an emulator or connected Android phone in Android Studio and press Run. Alternatively use `npm run android:run`.

For Android to reach your deployed backend, set `VITE_API_BASE` to its HTTPS URL before `npm run android:sync`. The backend must allow the app's origin. Never embed private API keys in frontend code.

## 4. Install the web app on Android
After deploying the web app over HTTPS, open it in Chrome on Android and choose **Install app** or **Add to Home screen** from the browser menu.

## API endpoints
- `GET /api/health`
- `GET /api/characters`
- `GET /api/characters/{character_id}`

SQLite is created at `backend/team_lab.db` on first backend startup.

## Starter roster
Kachina, Gorou, Furina, Sucrose, Bennett and Xingqiu. Identity metadata only; mechanics will be added through sourced, versioned data.

## Build status
This adds cross-platform configuration, not a finished Play Store release. The native `android/` project is generated locally by `npm run android:add`; Android Studio is required to compile, sign and test the APK/AAB. Backend hosting and account-based cloud sync are not implemented yet.

## Next milestone
Build the automated game-data import pipeline and a normalized, patch-versioned mechanics schema.
