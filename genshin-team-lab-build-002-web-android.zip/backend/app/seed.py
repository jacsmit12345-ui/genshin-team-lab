from sqlmodel import Session, select
from .models import Character

STARTER_CHARACTERS = [
    Character(id="kachina", name="Kachina", rarity=4, element="Geo", weapon_type="Polearm", region="Natlan"),
    Character(id="gorou", name="Gorou", rarity=4, element="Geo", weapon_type="Bow", region="Inazuma"),
    Character(id="furina", name="Furina", rarity=5, element="Hydro", weapon_type="Sword", region="Fontaine"),
    Character(id="sucrose", name="Sucrose", rarity=4, element="Anemo", weapon_type="Catalyst", region="Mondstadt"),
    Character(id="bennett", name="Bennett", rarity=4, element="Pyro", weapon_type="Sword", region="Mondstadt"),
    Character(id="xingqiu", name="Xingqiu", rarity=4, element="Hydro", weapon_type="Sword", region="Liyue"),
]

def seed_characters(session: Session) -> None:
    existing = {c.id for c in session.exec(select(Character)).all()}
    for character in STARTER_CHARACTERS:
        if character.id not in existing:
            session.add(character)
    session.commit()
