from typing import Optional
from sqlmodel import SQLModel, Field

class Character(SQLModel, table=True):
    id: str = Field(primary_key=True)
    name: str
    rarity: int
    element: str
    weapon_type: str
    region: Optional[str] = None
    data_status: str = "identity_verified"
    data_version: str = "starter-001"

class CharacterRead(SQLModel):
    id: str
    name: str
    rarity: int
    element: str
    weapon_type: str
    region: Optional[str] = None
    data_status: str
    data_version: str
