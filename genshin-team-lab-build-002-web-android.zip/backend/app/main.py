from contextlib import asynccontextmanager
from typing import List
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlmodel import Session, select

from .database import create_db_and_tables, get_session
from .models import Character, CharacterRead
from .seed import seed_characters

@asynccontextmanager
async def lifespan(app: FastAPI):
    create_db_and_tables()
    with Session(engine_for_seed) as session:
        seed_characters(session)
    yield

from .database import engine as engine_for_seed

app = FastAPI(
    title="Genshin Team Lab API",
    version="0.1.0",
    description="Local-first API foundation for Genshin Team Lab.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "genshin-team-lab-api", "version": "0.1.0"}

@app.get("/api/characters", response_model=List[CharacterRead])
def list_characters(session: Session = Depends(get_session)):
    statement = select(Character).order_by(Character.name)
    return session.exec(statement).all()

@app.get("/api/characters/{character_id}", response_model=CharacterRead)
def get_character(character_id: str, session: Session = Depends(get_session)):
    character = session.get(Character, character_id.lower())
    if character is None:
        raise HTTPException(status_code=404, detail="Character not found")
    return character
