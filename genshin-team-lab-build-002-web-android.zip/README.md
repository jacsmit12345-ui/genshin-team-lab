# Genshin Team Lab — Build 002 (Web + Android PWA)

A responsive, installable web application foundation for mechanics-first Genshin Impact team theorycrafting. The same React app runs in desktop browsers, mobile browsers and as an installable Android Progressive Web App (PWA).

## What works in this build

- Responsive React + TypeScript frontend (Vite), including phone-sized layouts and touch-friendly controls
- Installable PWA manifest, app icons and standalone display mode
- Service worker for app-shell caching and offline fallback; successful API GET responses are cached for offline reuse
- FastAPI backend and SQLite database created automatically
- Starter character roster API
- Character selection and four-slot team workspace
- Selected team saved in browser local storage
- Health endpoint and API documentation

This is not yet a damage calculator. No unverified damage values or simulated results are presented. Offline mode can reopen the cached app shell and previously fetched API responses; it does not make the backend or uncached data available offline.

## Requirements

- Python 3.10+
- Node.js 20+ (includes npm)

## Start the backend

From the project root:

```bash
cd backend
python -m venv .venv
```

Activate the environment:

**Windows PowerShell**
```powershell
.venv\\Scripts\\Activate.ps1
```

**macOS / Linux**
```bash
source .venv/bin/activate
```

Install and run:

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0
```

Backend: http://127.0.0.1:8000  
API docs: http://127.0.0.1:8000/docs

## Start the web app

Open a second terminal from the project root:

```bash
cd frontend
npm install
npm run dev -- --host 0.0.0.0
```

Open the local URL printed by Vite, usually http://localhost:5173.

The Vite development server proxies `/api` requests to the local FastAPI backend. This avoids hard-coding `localhost` into the frontend and makes testing from another device on the same Wi-Fi possible.

## Install on Android

1. Run the backend and frontend on your development computer using the commands above.
2. Connect your Android phone to the same Wi-Fi network.
3. Find your computer's local network IP address (for example, `192.168.1.20`).
4. On the phone, open `http://COMPUTER-IP:5173` in Chrome. Replace `COMPUTER-IP` with the actual address.
5. For local-network testing, Vite serves the app but PWA installation/service-worker support may be restricted because browsers generally require HTTPS or localhost for secure-context features. For a proper install test, deploy the frontend over HTTPS.
6. Once deployed over HTTPS, open the site in Chrome, use **Install app** (or **Add to Home screen**, depending on Chrome version), and launch Team Lab from the Android home screen.

The installed PWA uses a standalone app window and the supplied Team Lab icon. It is the same app and data model as the website, not a separate Android codebase.

## Production deployment notes

- Serve the frontend over HTTPS; this is required for service workers and reliable PWA installation outside localhost.
- Configure `VITE_API_BASE` at frontend build time if the API is hosted on a different origin, e.g. `https://api.example.com`.
- Configure the FastAPI CORS allow-list for the deployed frontend origin before using a separate API domain. Do not use a wildcard origin with credentials.
- The current service worker caches the app shell and successful same-origin API GET responses. Review cache versioning whenever offline data formats change.
- A PWA can be installed from Chrome without publishing to Google Play. A Play Store release or deeper native Android integration can be added later with a Capacitor wrapper if needed.

## API endpoints

- `GET /api/health`
- `GET /api/characters`
- `GET /api/characters/{character_id}`

The SQLite database is created at `backend/team_lab.db` on first backend startup.

## Current starter roster

The seed data includes Kachina, Gorou, Furina, Sucrose, Bennett and Xingqiu. It contains identity metadata only. Character multipliers, passives, constellation effects and detailed mechanics will be added through sourced, versioned data in a later milestone.

## Next development milestone

Build the automated game-data import pipeline and a normalized, patch-versioned mechanics schema. Do not use this starter roster as a complete roster or treat it as a damage-ready database.
